#!/usr/bin/python

def DemoList():
    x = input("Enter List:-")
    print (x)
    # x is item
    #append(x)
    #extend(L) L is list
    #insert(i,x) i is index
    #remove(x)
    #pop([i])
    #index(x) index of x
    #count(x) counts number of times x appears in list
    #sort() in-place sorting
    #reverse() in-place reverse
    #del to remove multiple elements
#program to implement stack using list
# pop & append

# using lists as queues
#from collections import deque

def DemoTuple():
    # tuples are immutable
    # tu = ()
    # tu= 'hello',

def DemoSets():
    # unique elements

if __name__ == '__main__':
    DemoList()
