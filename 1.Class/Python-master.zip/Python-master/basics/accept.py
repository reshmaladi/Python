#!/usr/bin/python

name = input("Enter Name:")
print("Hello "+name)
