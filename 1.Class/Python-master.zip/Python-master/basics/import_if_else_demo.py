#!/usr/bin/python

import if_else_demo

print(if_else_demo.Add(100, 200))
