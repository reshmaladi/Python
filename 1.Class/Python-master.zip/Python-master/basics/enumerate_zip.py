x = ['a', 'b','c', 3,4,5]

for i, z in enumerate(x):
    print i, z

y = ['a', 'b','c', 3,4,5]

for i, z in zip (x,y):
    print i, z
