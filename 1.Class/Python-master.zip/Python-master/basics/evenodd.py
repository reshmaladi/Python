#!/usr/bin/python
def evenodd():
	x = input("Please enter an integer:-")
	if x & 1:
		print "Number is odd"
	else:
		print "Number is even"

evenodd()
