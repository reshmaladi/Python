import bitwiseimport as bit

x = bit.TurnOffRightMostBit(10)
print x
