#!/usr/bin/python

class Foo(object): pass

print(isinstance(Foo, object))
print(type(Foo))
