
class Simple:
    def __call__(self):
        print("Invoked")

s = Simple()
s()
