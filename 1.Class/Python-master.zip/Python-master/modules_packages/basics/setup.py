from distutils.core import setup

setup(name = "basics", version="1.1", py_modules=['test'], packages=['history', 'operators', 'control_flow', 'data_types'])

