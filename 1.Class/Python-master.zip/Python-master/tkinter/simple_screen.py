#HelloWorld.py
import sys
import Tkinter
'''
root = Tkinter.Tk()
l = Tkinter.Label(root, text="Hello, world!\nTkinter on PocketPC!\nSee http://pythonce.sf.net.")
b = Tkinter.Button(root, text='Quit', command=root.destroy)
l.pack()
b.pack()
root.mainloop()
'''
top = Tkinter.Tk()
# Code to add widgets will go here...
top.mainloop()
