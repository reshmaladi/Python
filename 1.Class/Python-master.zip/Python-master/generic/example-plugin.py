def hello():
    print("Hello Module Demo")
