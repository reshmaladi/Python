x=input("Enter a string : ")
print("Reverse string : " + x[::-1])