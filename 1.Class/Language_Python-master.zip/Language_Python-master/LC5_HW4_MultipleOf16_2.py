x = eval(input("Enter no:\t"))
if x&~(15)==0 :
	print(x," is a devisor of 16")
else:
	print(x," is not a devisor of 16")