i="* "
j="  "
for x in range(1,7,1):
	print(i*x)
	

	
'''
print(j*(7-x) + i*x)



'''