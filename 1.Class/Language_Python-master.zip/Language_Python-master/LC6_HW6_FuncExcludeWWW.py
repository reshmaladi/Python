def func(x):
	print("Result: "+x[0:2:1]+x[:-3:-1])
	

x = input("Enter a string \t")
func(x)