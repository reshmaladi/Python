def swap():
	x = input("Enter a 1st string \t")
	y = input("Enter a 2nd string \t")
	print("Swap : \n" + y[0:2] +x[2:] + "\n" + x[0:2] + y[2:])
	
swap()