def name():
	print("Enter name")
	x = input("")
	print("Hello " + x)

name()