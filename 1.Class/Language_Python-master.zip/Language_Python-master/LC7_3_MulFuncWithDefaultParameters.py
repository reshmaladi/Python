def mul(a,b=1,c=1,d=1,e=1):
	return a*b*c*d*e

print(mul(10,20))
print(mul(10,20,30))
print(mul(10,20,30,40))
print(mul(10,20,30,40,50))