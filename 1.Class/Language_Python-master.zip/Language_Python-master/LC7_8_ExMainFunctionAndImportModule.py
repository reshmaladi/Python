def AD(a,b):
	return a+b

if __name__=='__main__':
	x,y=eval(input("Enter two numbers"))
	print(AD(x,y))