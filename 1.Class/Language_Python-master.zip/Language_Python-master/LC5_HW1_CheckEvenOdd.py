x = eval(input("Enter no:\t"))
if x&1:
	print(x," is odd")
else:
	print(x, "is even")