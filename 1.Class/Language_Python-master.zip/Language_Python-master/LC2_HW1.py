print("Enter name")
x = input("")
print("Hello " + x)
