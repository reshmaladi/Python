import logging

logging.basicConfig(filename = 'log_to_file',level = logging.DEBUG)
logging.debug('yoo1')
logging.error('yoo2')
logging.critical('yoo3')

