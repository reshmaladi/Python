x = input("Enter a string \t")
print("Result: "+x[0:2:1]+x[:-3:-1])