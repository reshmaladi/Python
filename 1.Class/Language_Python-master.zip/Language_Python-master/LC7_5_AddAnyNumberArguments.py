def variable(*a):
	v=0
	for x in a:
		v=v+x
	print(v)
		
#variable()
variable(1)
variable(1,2,3,4)
variable(100,20,50,40,70,10,90,101)
#variable(1,"Hello",2,[1,7,11],100)