x=eval(input("Enter no1\t"))

if x>=0 and x<=2:
	print("too few donuts")
elif x<=10:
	print("donuts:" ,x)
elif x>10:
	print("so many donuts")
else:
	print("not even tried donuts :D")