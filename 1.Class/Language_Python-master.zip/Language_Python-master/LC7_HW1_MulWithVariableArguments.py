def mul(*a):
	v=1
	for x in a:
		v=v*x
	print(v)
		
#mul()
mul(1)
mul(1,2,3,4)
mul(100,20,50,40,70,10,90,101)
#mul(1,"Hello",2,[1,7,11],100)