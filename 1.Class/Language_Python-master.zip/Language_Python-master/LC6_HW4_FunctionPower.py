def pow():
	x=eval(input("Enter two numbers\n"))
	y=eval(input(""))
	print("Result :" + str(x**y))
	
pow()