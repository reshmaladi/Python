def check(a,b,*d):
	print(type(a))
	print(type(b))
	print(type(d))
	
check(1,2,3,4,5)