def add(a,b,c=0,d=0,e=0):
	return a+b+c+d+e

print(add(10,20))
print(add(10,20,30))
print(add(10,20,30,40))
print(add(10,20,30,40,50))