x = eval(input("Enter X \t"))
y = eval(input("Enter Y \t"))
print(x+y)
